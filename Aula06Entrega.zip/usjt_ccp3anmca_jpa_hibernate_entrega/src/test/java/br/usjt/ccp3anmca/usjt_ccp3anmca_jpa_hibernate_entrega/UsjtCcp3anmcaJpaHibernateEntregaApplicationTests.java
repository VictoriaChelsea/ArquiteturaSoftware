package br.usjt.ccp3anmca.usjt_ccp3anmca_jpa_hibernate_entrega;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class UsjtCcp3anmcaJpaHibernateEntregaApplicationTests {

	@Test
	public void contextLoads() {
	}

}
