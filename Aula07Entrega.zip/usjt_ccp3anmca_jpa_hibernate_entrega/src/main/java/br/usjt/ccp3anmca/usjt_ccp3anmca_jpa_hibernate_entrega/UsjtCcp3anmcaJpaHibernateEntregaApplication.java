package br.usjt.ccp3anmca.usjt_ccp3anmca_jpa_hibernate_entrega;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsjtCcp3anmcaJpaHibernateEntregaApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsjtCcp3anmcaJpaHibernateEntregaApplication.class, args);
		
	}

}
