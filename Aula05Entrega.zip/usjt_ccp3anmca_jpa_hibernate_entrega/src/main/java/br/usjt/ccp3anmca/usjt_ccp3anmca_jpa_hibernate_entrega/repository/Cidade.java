package br.usjt.ccp3anmca.usjt_ccp3anmca_jpa_hibernate_entrega.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import br.usjt.ccp3anmca.usjt_ccp3anmca_jpa_hibernate_entrega.model.Previsao;

public interface Cidade extends JpaRepository<Cidade, Long>{
	
	public List <Cidade> findByLatitudeAndLongitude (String latitude, String longitude);
	
	public List <Cidade> queryByNome (String nome);
	 
	public Cidade queryByNomeIgnoreCase (String nome);

}
